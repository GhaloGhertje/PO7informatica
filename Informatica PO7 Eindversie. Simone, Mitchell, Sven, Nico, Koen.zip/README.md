# Relativiteitstheorie (PO7 Informatica)
Project van Koen, Sven, Mitchell, Simone en Nico over de speciale relativiteitstheorie.

## Gebruiksaanwijzing
Dit is de gebruiksaanwijzing voor ons programma.

Spatie = zet de klokken op pauze of start de klokken, 
R = reset de timers, 
P = wisselt van perspectief, 
D = het aantal decimalen van de snelheid met de eenheid "c",

Pijltje naar boven = volgende simulatie, 
pijltje naar onder = vorige simulatie,

Klikken op de snelheids-slider = verandert de snelheid naar de muispositie, 
pijltje naar rechts = (afgerond) +0,1 c bij de snelheid toevoegen, 
pijltje naar links = (afgerond) -0,1 c bij de snelheid toevoegen

Simulatie 1 = tijddilatatie, 
simulatie 2 = lengtecontractie, 
simulatie 3 = tijddilatatie + lengtecontractie
