class Reset():
    reset = print('reset')