class Insert():
    insert = print('insert')