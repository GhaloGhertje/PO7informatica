import sys, pygame

class Stop():
    def exit():
        print('exit')
        pygame.quit()
        sys.exit()